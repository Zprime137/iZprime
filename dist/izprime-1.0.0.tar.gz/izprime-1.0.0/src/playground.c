/**
 * @file playground.c
 * @brief Scratch space for testing new ideas.
 */

#include <iZ_api.h>
